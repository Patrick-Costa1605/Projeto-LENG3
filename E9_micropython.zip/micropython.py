# mqtt_demo # mqttdemo.py
from mqtt_as import MQTTClient
from mqtt_as import config
import uasyncio as asyncio
#import ujson
#Beginning of added code
#import serial
from machine import UART
#End of added code
#from machine import UART, Pin, ADC
#import ujson
#import time

config["server"] = "mqtt.eu.thingsboard.cloud"  # Change these
config["user"] =  "equipa9"          # defined on the TB device 
config["password"] = "maxi757:redo"       #  idem 

config["ssid"] = "LENG3a"
config["wifi_pw"] = "nefsloiat"

# function to be called when a message is received 
# def callback(topic, msg, retained):
#    print((topic, msg, retained))

#  how to subscribe 
#async def conn_han(client):
#    await client.subscribe("outTopic", 1)

async def main(client):
    #await client.connect()
    await client.connect()
    n = 0
    inc = 1
    #Beginning of added code
    if _name_ == '_main_':
        #ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
        #New Form
        #ser = serial.Serial(port='/dev/serial0', baudrate=9600, timeout=1)
        uart=UART(0, baudrate=9600, tx=0, rx=1)
        #Bring this back if necessary: ser.reset_input_buffer()
        #End of added code
        while True:
            #Beginning of added code
            await asyncio.sleep(1)
            #uart_data = uart.readline().decode('utf-8').rstrip(",") #Tirar isto se necessário
            #lixo=uart.readline()
            #if lixo is not None:
                #motor1=uart.readline().decode('utf-8').rstrip()
            
            
            
            #motor1=uart.readline()
            #if motor1 is not None:
                #print(f"Raw data of 1: {motor1}")
                #motor1=motor1.decode('utf-8').strip()
                #print("\nEstou dentro do if 1")
            #await asyncio.sleep(1)
            
                #motor2=uart.readline().decode('utf-8').rstrip()
            
            #motor2=uart.readline()
            #if motor2 is not None:
                #print(f"Raw data of 2: {motor2}")
                #motor2=motor2.decode('utf-8').strip()
                #print("\nEstou dentro do if 2")
            #await asyncio.sleep(1)
            
                #volta1=uart.readline().decode('utf-8').rstrip()
            
            #volta1=uart.readline()
            #if volta1 is not None:
                #print(f"Raw data of 3: {volta1}")
                #volta1=volta1.decode('utf-8').strip()
                #print("\nEstou dentro do if 3")
            #await asyncio.sleep(1)
            
                #volta2=uart.readline().decode('utf-8').rstrip()
            
            #volta2=uart.readline()
            #if volta2 is not None:
                #print(f"Raw data of 4: {volta2}")
                #volta2=volta2.decode('utf-8').strip()
                #print("\nEstou dentro do if 4")
            #await asyncio.sleep(1)
            
                #volta3=uart.readline().decode('utf-8').rstrip()
            
            #volta3=uart.readline()
            #if volta3 is not None:
                #print(f"Raw data of 5: {volta3}")
                #volta3=volta3.decode('utf-8').strip()
                #print("\nEstou dentro do if 5")
                
            #print("olá", motor1)
            #print("olá 2", motor2)
            #print("olá 3", volta1)
            #print("olá 4", volta2)
            #print("olá 5", volta3)
            
            
            
            
                #End of added code
                #await asyncio.sleep(5)
                #print("publish", n)
                # If WiFi is down the following will pause for the duration.
                #
                #                    Change these according to the TB definition:
            #if client.isconnected():
                #await client.publish("v1/devices/me/telemetry", "{Motor_1:"+"{}".format(motor1)+"}", qos=1)
                #await client.publish("v1/devices/me/telemetry", "{Motor_2:"+"{}".format(motor2)+"}", qos=1)
                #await client.publish("v1/devices/me/telemetry", "{Volta_1:"+"{}".format(volta1)+"}", qos=1)
                #await client.publish("v1/devices/me/telemetry", "{Volta_2:"+"{}".format(volta2)+"}", qos=1)
                #await client.publish("v1/devices/me/telemetry", "{Volta_3:"+"{}".format(volta3)+"}", qos=1)
                #print("Estou dentro do if! !")
            #else:
                #print("Failed to publish: MQTT client not connected.")
                
            dataLida=uart.readline()
            print(dataLida)
            if dataLida is not None:
                dataLida=dataLida.decode('utf-8')
                dataLida=dataLida.strip()
                if client.isconnected():
                    await client.publish("v1/devices/me/telemetry", dataLida, qos=1)
            print("\n\nCheguei ao fim")
            print(dataLida)
            n += inc 
            if (n==20) or (n==0):
                inc = -inc
            
        

# config["connect_coro"] = conn_han
# config["subs_cb"] = callback
MQTTClient.DEBUG = True  # Optional: print diagnostic messages
client = MQTTClient(config)
try:
    asyncio.run(main(client))
finally:
    client.close()  # Prevent LmacRxBlk:1 errors
    print("Coneçao encerrada.")